(function(scope) {

    var HostContext = {

        getVersion: function() {
            return "1.0.0";
        },

        callFunction: function(name, options) {
            var location = "twssobridge://" + name;

            var jsonString = JSON.stringify(options);
            if (options) {
                location += "?" + jsonString;
            }

            if (scope.AndroidNativeApp) {
                scope.AndroidNativeApp.callFunction(name, jsonString);
                return;
            }

            var iframe = document.createElement("IFRAME");
            iframe.setAttribute("src", location);
            document.documentElement.appendChild(iframe);
            iframe.parentNode.removeChild(iframe);
            iframe = null;
        }
    };

    if (scope._TWSSO) {

        if (scope._TWSSO.HostContext) {
            scope._TWSSO.HostContext = HostContext;
        } else {
            var msg = "Can not override native version of HostContext instead of web version. because the web version of HostContext is not exist!";
            throw new Error(msg);
        }
    } else {
        var msg = "Can not inject native version HostContext to web page because namespace _TWSSO is not exist!";
        throw new Error(msg);
    }

})(window);
