// AppContext Android version v1.0.1


(function (scope) {



    var AppContext = {
        _eventListeners: [],

        getVersion: function () {
            return "1.0.1";
        },
        isHybridApp: function () {
            return true;
        },
        getPlatform: function () {
            return "android";
        },
        callFunction: function (name, options) {
            var location = "twhybridappbridge://" + name;

            var jsonString = JSON.stringify(options);
            if (options) {
                location += "?" + jsonString;
            }

            if (scope.AndroidNativeApp) {
                scope.AndroidNativeApp.callFunction(name, jsonString);
                return;
            }

            var iframe = document.createElement("IFRAME");
            iframe.setAttribute("src", location);
            document.documentElement.appendChild(iframe);
            iframe.parentNode.removeChild(iframe);
            iframe = null;
        },
        addEventListener: function(name, callback) {
            if (!this._eventListeners.hasOwnProperty(name)) {
                this._eventListeners[name] = [];
            }
            this._eventListeners[name].push(callback);
            //window.alert("AppContext.addEventListener(); eventName=" + name + " ,length=" + this._eventListeners[name].length);
        },
        removeEventListener: function(name, callback) {
            if (this._eventListeners.hasOwnProperty(name)) {
                var callbacks = this._eventListeners[name];
                var restricted = [];
                for (var i = 0; i < callbacks.length; i++) {
                    if (callbacks[i] != callback) {
                        restricted.push(callbacks[i])
                    }
                }
                this._eventListeners[name] = restricted;
                //window.alert("AppContext.removeEventListener(); eventName=" + name + " ,length=" + this._eventListeners[name].length);
            //} else {
                //window.alert("AppContext.removeEventListener(); eventName=" + name + " ,length=0");
            }
        },
        triggerEvent: function(name, options) {
            var appContext = _TW.AppContext;
            if (this._eventListeners.hasOwnProperty(name)) {
                var listeners = this._eventListeners[name];
                //window.alert("WebContext.triggerEvent(); name=" + name + ", length=" + listeners.length);
                for (var i = 0; i < listeners.length; i++) {
                    if (options) {
                        listeners[i](options);
                    } else {
                        listeners[i]();
                    }
                }
            //} else {
                //window.alert("WebContext.triggerEvent(); name=" + name + ", length=0");
            }
        }
    };



    if (scope._TW) {
        if (scope._TW.AppContext) {
            scope._TW.AppContext = AppContext;
        } else {
            var msg = "Can not override native version of AppContext instead of web version. because the web version of AppContext is not exist!";
            throw new Error(msg);
        }
    } else {
        var msg = "Can not inject native version AppContext to web page because namespace _TW is not exist!";
        throw new Error(msg);
    }




})(window);